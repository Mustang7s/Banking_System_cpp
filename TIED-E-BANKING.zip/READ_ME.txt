                      WELCOME TO TIED E-BANKING SYSTEM
//Developed By...: The TIED Group
//
//Name: Mactilda Matsotso
//Reg No: 145187
//
//Name: Rutto Evans
//Reg No:139691
//
//Name: Dorry Omondi
//Reg No: 140351
//
//Submitted to : Mr.Kelvin Ndambuki

//Project Name : Electronic Banking System



A simple Banking System (TIED ELectronic Banking system )has been implemented with the help of C++ functions,structures etc.
The user must create an account with the "C++ Admin" then must authenticate themselves by logging into thier bank account to view the menu of options.


Following functionalities are allowed in this Banking System:

1.Open an Account in the Bank
2.Balance Enquiry of the Account
3.Deposit amount in a Bank Account
4.Withdrawal of amount from a Bank Account
5.Change PasswordAdvantage of TIED Banking System
1.Customer's data is  stored,hence  data ends up being stored for reference.
2.Passwords and Username are saved for authentication.

